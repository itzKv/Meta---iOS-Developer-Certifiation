//
//  MenuViewViewModel.swift
//  DinnerMenu
//
//  Created by Kevin Brivio on 01/07/24.
//

import Foundation

