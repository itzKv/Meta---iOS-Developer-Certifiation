//
//  DinnerMenuApp.swift
//  DinnerMenu
//
//  Created by Kevin Brivio on 28/06/24.
//

import SwiftUI

@main
struct DinnerMenuApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
